//
//  Dodgeball.h
//  Dodgebomb
//
//  Created by Jeff Hsu on 7/13/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "CCSprite.h"

@interface Dodgeball : CCSprite
- (id)initDodgeball;
-(void)setBallHolder:(CCSprite *)hero;
-(void)setNewPosition;
@property (nonatomic, assign) BOOL held;
@property (nonatomic, assign) CGPoint pos;
@property (nonatomic, assign) CCSprite *heroToFollow;
@property (nonatomic, assign) CGPoint *offset;


@end
