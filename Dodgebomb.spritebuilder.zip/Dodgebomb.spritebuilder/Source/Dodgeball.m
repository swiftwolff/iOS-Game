//
//  Dodgeball.m
//  Dodgebomb
//
//  Created by Jeff Hsu on 7/13/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "Dodgeball.h"

@implementation Dodgeball
- (id)initDodgeball
{
    //since we made Creature inherit from CCSprite, 'super' below refers to CCSprite
    self = [super initWithImageNamed:@"dodgeballAssets/Billiard_Balls_01_White_256x256@1x.png"];
    
    return self;
}
- (void)didLoadFromCCB
{
    CCLOG(@"dodgeball collisionType initialized");
    
    self.physicsBody.collisionType = @"dodgeball";
    
    
}
-(void)setBallHolder:(CCSprite *)hero
{
    self.heroToFollow = hero;
}
-(void)setNewPosition
{
    
    [CCActionMoveTo actionWithDuration:0.1f position:self.heroToFollow.position];
}

@end
