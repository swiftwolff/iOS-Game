//
//  Gameplay.h
//  Dodgebomb
//
//  Created by Jeff Hsu on 7/13/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "CCNode.h"

@interface Gameplay : CCNode <CCPhysicsCollisionDelegate>
- (id)init;

@end