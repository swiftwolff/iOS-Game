//
//  GreenHero.h
//  Dodgebomb
//
//  Created by Jeff Hsu on 7/13/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "CCSprite.h"

@interface GreenHero : CCSprite
- (id)initGreenHero;
- (void)stopRunning;
- (void)startRunning;
@property (nonatomic, assign) BOOL alive;
@end