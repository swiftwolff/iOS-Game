//
//  GreenHero.m
//  Dodgebomb
//
//  Created by Jeff Hsu on 7/13/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "GreenHero.h"

@implementation GreenHero
- (id)initGreenHero
{
    //since we made Creature inherit from CCSprite, 'super' below refers to CCSprite
    self = [super initWithImageNamed:@"dodgeballAssets/p1_stand@4x.png"];
    
    return self;
}

- (void)didLoadFromCCB
{
    CCLOG(@"greenhero collisionType initialized");
    self.physicsBody.collisionType = @"greenhero";
    
    //stop the animation
}

-(void)stopRunning
{
    CCAnimationManager* animationManager = self.animationManager;
    [animationManager setPaused:YES];
}

- (void)startRunning
{
    CCAnimationManager* animationManager = self.animationManager;
    [animationManager setPaused:NO];
}
@end
