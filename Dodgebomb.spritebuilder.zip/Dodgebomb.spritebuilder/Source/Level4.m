//
//  Level4.m
//  Dodgebomb
//
//  Created by Jeff Hsu on 7/19/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "Level4.h"
#import "GreenHero.h"
#import "Dodgeball.h"
#import "CCPhysics+ObjectiveChipmunk.h"

@implementation Level4{
    CCNode *_levelNode;
    GreenHero *_greenHero;
    Dodgeball *_dodgeball;
    Dodgeball *_incoming;
    CCPhysicsNode *_physicsNode;
    CCNode *_contentNode;
    CGSize _screenSize;
    CCLabelTTF *_bombLeft;
    CCLabelTTF *_succeed;
    CCLabelTTF *_failed;
    int count;
}

- (id)init
{
    if (self = [super init])
    {
        // activate touches on this scene
        self.userInteractionEnabled = TRUE;
    }
    return self;
}


- (void)didLoadFromCCB {
    _physicsNode.collisionDelegate = self;
    //    CCScene *level = [CCBReader loadAsScene:@"Levels/Level1"];
    //    [_levelNode addChild:level];
    count = 25;
    _bombLeft.string = [NSString stringWithFormat:@"%d", count];
    
    
}

- (void)onEnter
{
    _succeed.visible = NO;
    _failed.visible = NO;
    [super onEnter];
    [_greenHero stopRunning];
    self.userInteractionEnabled = TRUE;
    [self schedule:@selector(dropball) interval:0.8];
    _screenSize = [[CCDirector sharedDirector] viewSize];
    //need to set the contentSize here to enable the touch
    self.contentSize = _screenSize;
    _greenHero.alive = YES;
    NSLog(@"contentSize x: %f", self.contentSize.width);
    NSLog(@":contentSize y %f", self.contentSize.height);
    
    
}

-(void)dropball{
    CCSprite *dropingball = (Dodgeball*)[CCBReader load:@"ball"];
    int positionX = arc4random()% (int)_screenSize.width;
    [dropingball setPosition:ccp(positionX,_screenSize.height+10)];
    [_physicsNode addChild:dropingball];
    
    id delay = [CCActionDelay actionWithDuration: 10];
    id callbackAction = [CCActionCallBlock actionWithBlock:^{
        // load particle effect
        CCParticleSystem *explosion = (CCParticleSystem *)[CCBReader load:@"Explosion"];
        // make the particle effect clean itself up, once it is completed
        explosion.autoRemoveOnFinish = TRUE;
        // place the particle effect on the seals position
        explosion.position = dropingball.position;
        // add the particle effect to the same node the seal is on
        [dropingball.parent addChild:explosion];
        [_physicsNode removeChild:dropingball];
    }];
    id sequence = [CCActionSequence actions: delay, callbackAction, nil];
    [self runAction: sequence];
    
    count = count - 1;
}

-(void)removeBall:(CCSprite *)ball
{
    
    if(ball!=nil){
        [_physicsNode removeChild:ball];
    }
    
}

- (void)touchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    //get the x,y coordinates of the touch
    CGPoint touchLocation = [touch locationInNode:self];
    [_greenHero startRunning];
    
    CGPoint start = _greenHero.position; // here you will get the current position of your sprite.
    
    //make sure hero moves in constant speed
    float distance = ccpDistance(start, touchLocation); // now you have the distance
    float speed = 150;
    float duration = distance/speed;  // here you find the duration required to cover the distance at constant speed
    
    //move hero's head
    CGPoint moveDifference = ccpSub(touchLocation, _greenHero.position);
    if (moveDifference.x > 0) {
        _greenHero.flipX = NO;
    } else {
        _greenHero.flipX = YES;
    }
    
    
    CCActionMoveBy* moveToSomeAwesomePlace = [CCActionMoveTo actionWithDuration:duration position:touchLocation];
    CCActionCallBlock *actionAfterMoving = [CCActionCallBlock actionWithBlock:^{
        [_greenHero stopRunning];
    }];
    CCActionSequence *movingSequeceAndOtherStuffAfter = [CCActionSequence actionWithArray:@[moveToSomeAwesomePlace, actionAfterMoving]];
    
    [_greenHero runAction:movingSequeceAndOtherStuffAfter];
    NSLog(@"dodgeball: %f", _dodgeball.position.x);
    NSLog(@"dodgeball: %f", _dodgeball.position.y);
    
    NSLog(@"x: %f", touchLocation.x);
    NSLog(@":y %f", touchLocation.y);
}

-(void)ccPhysicsCollisionPostSolve:(CCPhysicsCollisionPair *)pair greenhero:(CCSprite *)nodeA dodgeball:(CCSprite *)nodeB
{
    CCLOG(@"greenhero and dodgeball collided");
    _dodgeball.held = YES;
    //    [_dodgeball setBallHolder:_greenHero];
    [self removeHero];
    nodeB.visible = 0;
    //    [self removeBall:nodeB];
    
}

-(void) touchEnded:(UITouch *)touch withEvent:(UIEvent *)event{
    // when touches end, meaning the user releases their finger, release the catapult
    //    [_greenHero stopRunning];
}

-(void) removeHero
{
    // load particle effect
    CCParticleSystem *explosion = (CCParticleSystem *)[CCBReader load:@"Explosion"];
    // make the particle effect clean itself up, once it is completed
    explosion.autoRemoveOnFinish = TRUE;
    // place the particle effect on the hero position
    explosion.position = _greenHero.position;
    // add the particle effect to the same node the hero is on
    [_greenHero.parent addChild:explosion];
    
    // finally, remove the destroyed hero
    [_greenHero removeFromParent];
    
    //mark green alive is NO
    _greenHero.alive = NO;
    _failed.visible = YES;
    
}

- (void)loadNextLevel
{
    CCActionDelay *delay =  [CCActionDelay actionWithDuration:3];
    CCActionCallBlock *delayedAction = [CCActionCallBlock actionWithBlock:^{
        CCScene *gameplayScene = [CCBReader loadAsScene:@"Level5"];
        [[CCDirector sharedDirector] replaceScene:gameplayScene];
    }];
    
    CCActionSequence *delayedSeq = [CCActionSequence actionWithArray:@[delay, delayedAction]];
    
    [self runAction:delayedSeq];
}



//method gets called every frame on every of your scenes
- (void)update:(CCTime)delta
{
    if(count<=0){
        [self unschedule:@selector(dropball)];
        if(_greenHero.alive==YES){
            _succeed.visible = YES;
            [self loadNextLevel];
            _greenHero.alive = NO;
        }
    }
    if(_greenHero.position.y < 0){
        _failed.visible = YES;
        _greenHero.alive = NO;
    }
    _bombLeft.string = [NSString stringWithFormat:@"%d", count];
    
}

- (void)retry {
    // reload this level
    [[CCDirector sharedDirector] replaceScene: [CCBReader loadAsScene:@"Level4"]];
}

@end