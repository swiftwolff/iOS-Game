//
//  Level5.h
//  Dodgebomb
//
//  Created by Jeff Hsu on 7/19/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "CCNode.h"

@interface Level5 : CCNode <CCPhysicsCollisionDelegate>
- (id)init;
@end