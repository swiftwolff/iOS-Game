//
//  Gameplay.h
//  PeevedPenguins
//
//  Created by Jeff Hsu on 6/8/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "CCNode.h"

@interface Gameplay : CCNode <CCPhysicsCollisionDelegate>

@end
